import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HomeComponent } from './home.component';
import { By } from '@angular/platform-browser';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ObraService } from '../services/obra.service'; // Asegúrate de que la ruta de importación sea correcta
import { of } from 'rxjs';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let obrasServiceMock: any;

  beforeEach(async () => {
    obrasServiceMock = jasmine.createSpyObj('ObrasService', ['getObras']);
    obrasServiceMock.getObras.and.returnValue(of([
      { id: 1, imagen_url: 'url1', titulo: 'Obra 1', descripcion: 'Descripción 1', id_reservas_teatrales: 'sala1' },
      { id: 2, imagen_url: 'url2', titulo: 'Obra 2', descripcion: 'Descripción 2', id_reservas_teatrales: 'sala2' }
    ])); 

    await TestBed.configureTestingModule({
      declarations: [ HomeComponent ],
      imports: [ HttpClientTestingModule, RouterTestingModule ], 
      providers: [ { provide: ObraService, useValue: obrasServiceMock } ] 
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges(); 
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('debería obtener las obras y asignarlas a la propiedad shows', () => {
    expect(obrasServiceMock.getObras).toHaveBeenCalled();
    expect(component.shows.length).toBe(2); 
  });

  it('debería renderizar los títulos de las obras', () => {
    const obraTitles = fixture.debugElement.queryAll(By.css('.show-title')); 
    expect(obraTitles.length).toBe(2);
    expect(obraTitles[0].nativeElement.textContent).toContain('Obra 1');
    expect(obraTitles[1].nativeElement.textContent).toContain('Obra 2');
  });
});
